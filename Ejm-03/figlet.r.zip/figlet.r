# Rich FitzJohn (s.f.)
# rfiglet https://richfitz.github.io/rfiglet/
#----------------------------------
# archivo:  figlet.r
#
# Entrar en R e instalar: 
# remotes::install_github("richfitz/rfiglet", upgrade = FALSE)

library(rfiglet)

figlet("Intro   a   R")







