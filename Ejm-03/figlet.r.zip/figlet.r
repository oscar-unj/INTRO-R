# Rscript figlet.r

library(rfiglet)

figlet("Intro   a   R")

# Autor Rich FitzJohn (s.f.). rfiglet.
# https://richfitz.github.io/rfiglet/







