# Rscript instalar_figlet.r
# Instalar una sola vez.
remotes::install_github("richfitz/rfiglet", upgrade = FALSE)



