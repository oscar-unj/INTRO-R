# Rscript instalar_figlet.r

remotes::install_github("richfitz/rfiglet", upgrade = FALSE)



