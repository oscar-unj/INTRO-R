# Instalar una sola vez.
#
install.packages("ggplot2")
#
# Rscript instalar_ggplot2.r




