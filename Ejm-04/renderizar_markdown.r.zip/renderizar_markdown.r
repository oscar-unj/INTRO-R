
library(rmarkdown)

# Renderizar el documento en PDF
render("doc_markdown.rmd", output_format = "pdf_document")

###  REFERENCIA
###  OpenAI (2024). ChatGPT. (Versión del 01 de Julio)
###  [Render PDF using RMarkdown ].
###  https://chatgpt.com/share/0c5530b8-f01b-4f6c-a4a7-3897ad8d0f4a


