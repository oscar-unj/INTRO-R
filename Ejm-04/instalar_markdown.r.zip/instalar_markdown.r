# Solo se instala una vez.
install.packages("rmarkdown")
install.packages("knir")
install.packages("pandoc")
install.packages("tinytex")

###  Basado en:
###  OpenAI (2024). ChatGPT. (Versión del 01 de Julio)
###  [Render PDF using RMarkdown ].
###  https://chatgpt.com/share/0c5530b8-f01b-4f6c-a4a7-3897ad8d0f4a


