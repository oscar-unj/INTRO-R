
# Instalación de librerías necesarias
# para actualizar el repositorio de cran
options(repos = c(CRAN = "https://cran.r-project.org")) 
install.packages("h2o")
install.packages("ggplot2")
install.packages("gridExtra") 
install.packages("grid")




