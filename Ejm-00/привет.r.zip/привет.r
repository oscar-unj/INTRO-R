# Rscript привет.r

print("доброе утро, парни")

